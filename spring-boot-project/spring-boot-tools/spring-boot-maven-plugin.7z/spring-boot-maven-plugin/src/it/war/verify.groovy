import java.io.*;
import org.springframework.boot.maven.*;

Verify.verifyWar(
	new File(basedir, "target/war-0.0.1.BUILD-SNAPSHOT.war")
)

